package com.tiagoamp.helloworld.mbean;

import javax.faces.bean.ManagedBean;

@ManagedBean(name = "helloBean")
public class HelloBean {

    private String nome = "Tiago";
    private Integer pontos = 10;

    public String getNome() {
        return nome;
    }
    public Integer getPontos() {
        return pontos;
    }

}


package br.sc.senai.mbean;

import javax.faces.bean.ManagedBean;

@ManagedBean(name = "helloBean")
public class HelloBean {

    public HelloBean() {
        System.out.println("HelloWorld started!");
    }

    public String getMessage() {
        return "Hello World!!!";
    }

}
